#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <fstream>
#include <windows.h>

using namespace std;

void SetColor(int ForgC){
    WORD wColor;
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
    return;
}

int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}
// function to check if a number is prime
bool is_prime(int n) {
    if (n <= 1) {
        return false;
    }
    for (int i = 2; i <= sqrt(n); i++) {
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

// function to calculate the modular multiplicative inverse of a number
int mod_inverse(int a, int m) {
    a = a % m;
    for (int x = 1; x < m; x++) {
        if ((a * x) % m == 1) {
            return x;
        }
    }
    return -1; // inverse doesn't exist
}

// function to generate public and private keys
pair<pair<int, int>, pair<int, int>> generate_keys(int p, int q) {
    if (!(is_prime(p) && is_prime(q))) {
        SetColor(13);
        throw invalid_argument("<KLAIDA> abu skaiciai turi buti pirminiai");
        SetColor(15);
    }
    int n = p * q;
    int phi = (p - 1) * (q - 1);
    int e = 2;
    while (gcd(e, phi) != 1) {
        e++;
    }
    int d = mod_inverse(e, phi);
    return make_pair(make_pair(n, e), make_pair(n, d));
}

// function to encrypt a message
vector<int> encrypt(pair<int, int> pk, string plaintext) {
    int n = pk.first;
    int e = pk.second;
    vector<int> ciphertext;
    for (char c : plaintext) {
        int m = static_cast<int>(c);
        int encrypted_m = 1;
        for (int i = 0; i < e; i++) {
            encrypted_m = (encrypted_m * m) % n;
        }
        ciphertext.push_back(encrypted_m);
    }
    return ciphertext;
}


// function to decrypt a message
string decrypt(pair<int, int> pk, vector<int> ciphertext) {
    int n = pk.first;
    int d = pk.second;
    string plaintext = "";
    for (int c : ciphertext) {
        int decrypted_c = 1;
        for (int i = 0; i < d; i++) {
            decrypted_c = (decrypted_c * c) % n;
        }
        plaintext += static_cast<char>(decrypted_c);
    }
    return plaintext;
}

int main() {
    SetColor(14);
    cout << "          <RSA SIFRAVIMO/DESIFRAVIMO ALGORITMAS>" << endl;
    cout << "___________________________________________________________" << endl;
    cout << "<PIRMINIU SKAICIU IVEDIMAS>" << endl;
    //Raktu kurimas/generavimas
    int p;
    int q;
    SetColor(9);
    cout << "Iveskite p(pirminis skaicius) ir spauskite ENTER: ";
    SetColor(15);
    cin >> p;
    SetColor(9);
    cout << "Iveskite q(pirminis skaicius) ir spauskite ENTER: ";
    SetColor(15);
    cin >> q;
    auto keys = generate_keys(p, q);
    auto public_key = keys.first;
    auto private_key = keys.second;
    SetColor(14);
    cout << "___________________________________________________________" << endl;
    SetColor(15);
    //Pasirinkti, ar ivedame teksta, ar nuskaitome is failo
    int choice;
    SetColor(14);
    cout << "<MENIU>" << endl;
    cout << "1. Teksto ivedimas\n";
    cout << "2. Teksto skaitymas is failo\n";
    SetColor(9);
    cout << "Iveskite pasirinkima ir spauskite ENTER: ";
    SetColor(15);
    cin >> choice;
    if (choice == 1) {
        //Teksto ivedimas ir sifravimas
        string message;
        SetColor(9);
        cout << "Iveskite teksta ir spauskite ENTER: ";
        SetColor(15);
        cin.ignore(); //Ignoruojame '\n' simboli, kuris liko po skaitymo is pirmo cin objekto
        getline(cin, message);
        auto encrypted_message = encrypt(public_key, message);
        auto decrypted_message = decrypt(private_key, encrypted_message);

        //Ciphertext ir vieas raktas issaugojimas faile
        ofstream encrypted_file("encrypted_message.txt");
        for (int c : encrypted_message) {
            encrypted_file << c << " ";
        }
        encrypted_file.close();

        //Isvedimas
        SetColor(14);
        cout << "\n___________________________________________________________" << endl;
        cout << "<SUGENERUOTI RAKTAI>" << endl;
        cout << "Viesas raktas: (" << public_key.first << ", " << public_key.second << ")" << endl;
        cout << "Privatus raktas: (" << private_key.first << ", " << private_key.second << ")" << endl;
        SetColor(9);
        cout << endl;
        cout << "\nUzsifruotas tekstas: ";
        SetColor(34);
        for (int c : encrypted_message) {
            cout << c << " ";
        }
        SetColor(9);
        cout << "\nDesifruotas tekstas: ";
        SetColor(34);
        cout << decrypted_message << endl;
        SetColor(15);
        cout << endl;
    } else if (choice == 2) {
        //Nuskaityti uzsifruota teksta is failo
        ifstream encrypted_file("encrypted_message.txt");
        vector<int> encrypted_message;
        int c;
        while (encrypted_file >> c) {
            encrypted_message.push_back(c);
        }
        encrypted_file.close();

        //Teksto desifravimas
        auto decrypted_message = decrypt(private_key, encrypted_message);

        //Isvedimas
        SetColor(14);
        cout << "Viesas raktas: (" << public_key.first << ", " << public_key.second << ")" << endl;
        cout << "Privatus raktas: (" << private_key.first << ", " << private_key.second << ")" << endl;
        SetColor(9);
        cout << endl;
        cout << "Uzsifruotas tekstas: ";
        SetColor(34);
        for (int c : encrypted_message) {
            cout << c << " ";
        }
        cout << endl;
        SetColor(9);
        cout << "Desifruotas tekstas: ";
        SetColor(34);
        cout << decrypted_message << endl;
        SetColor(15);
    } else {
        SetColor(13);
        cout << "Neteisingas pasirinkimas." << endl;
        SetColor(15);
    }

    return 0;
}

